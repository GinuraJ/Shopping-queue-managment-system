import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.io.PrintWriter;

public class CWsd2_new {

    public static void main(String[] args) throws FileNotFoundException {

        menu();

        while (op){
            System.out.println();
            System.out.println("__________________________");
            System.out.print(  "Enter your option : ");
            String option = myObj.nextLine();                 // Get the option which user require
            System.out.println("______________________________________________");
            System.out.println();

            switch (option) {

                case "100", "VFQ" -> viewAllQueues();

                case "101", "VEQ" -> viewEmptyQueues();

                case "102", "ACQ" -> addCustomer();

                case "103", "RCQ" -> removeCustomer();

                case "104", "PCQ" -> removeServedCustomer();

                case "105", "VCS" -> sortedNames();

                case "106", "SPD" -> writeFile();

                case "107", "LPD" -> loadFile();

                case "108", "STK" -> System.out.println(noOfBurgersStock + " burgers in stock");

                case "109", "AFS" -> refillStock();

                case "999", "EXT" -> exit();

                default -> {
                    System.out.println("Please enter accurate option as above !!");
                    continue;
                }
            }

            while (againMenu){
                System.out.println();
                System.out.print("Do you want option menu again (y or n) : ");
                String again = myObj.nextLine();

                if(Objects.equals(again, "y" ) || Objects.equals(again, "yes")){
                    break;  // If user enter 'y' or 'yes', this loop will break and ask option again
                } else if (Objects.equals(again, "n") || Objects.equals(again, "no")) {
                    op = false;         // If user enter 'n',main loop will be stopped
                    againMenu = false;  // If user enter 'n',this loop will be stopped
                    break;
                }
            }
        }
    }

    static Scanner myObj = new Scanner(System.in);
    static String[][] q1 = {{"0","0","0"},{"0","0","0"}}; // Array for queue 1
    static String[][] q2 = {{"0","0","0"},{"0","0","0"},{"0","0","0"}}; // Array for queue 2
    static String[][] q3 = {{"0","0","0"},{"0","0","0"},{"0","0","0"},{"0","0","0"},{"0","0","0"}}; // Array for queue 3
    static String[][][] q123 = {q1,q2,q3};           // This array contains queue 1,2 and 3.
    static String[] viewq1 = {"X","X"};              // This array for display queue 1 positions occupied or not
    static String[] viewq2 = {"X","X","X"};          // This array for display queue 2 positions occupied or not
    static String[] viewq3 = {"X","X","X","X","X"};  // This array for display queue 3 positions occupied or not
    static String[][] waitingQueue = {{"0","0","0"},{"0","0","0"},{"0","0","0"},{"0","0","0"},{"0","0","0"},{"0","0","0"},{"0","0","0"},{"0","0","0"}};
    static int waitingNumber = 0;               // This variable used for add customers to waiting queue
    static int noOfBurgersStock = 50;           // Number of burgers in stock
    static boolean op = true;                   // This is for read option input
    static boolean againMenu = true;            //
    static boolean addedToQueue = true;
    static boolean rightQueue = true;
    static boolean rightPosition = true;
    static boolean noCustomers = false;
    static boolean queueEmpty = true;
    static boolean rightServedQueue = true;
    static int bugersSoldQ1 = 0;            // This variable is to maintain how many no.of burgers issued from queue 1
    static int bugersSoldQ2 = 0;            // This variable is to maintain how many no.of burgers issued from queue 2
    static int bugersSoldQ3 = 0;            // This variable is to maintain how many no.of burgers issued from queue 3

    public static void menu(){
        System.out.println("__________________________________________________________");
        System.out.println();
        System.out.println("                FOODIES FAVE FOOD CENTRE                  ");
        System.out.println("__________________________________________________________");
        System.out.println();
        System.out.println("100 or VFQ : View ALL Queues");
        System.out.println("101 or VEQ : View all Empty Queues");
        System.out.println("102 or ACQ : Add customer to a Queue");
        System.out.println("103 or RCQ : Remove a customer from a Queue");
        System.out.println("104 or PCQ : Remove a served customer");
        System.out.println("105 or VCS : View Customers Sorted in alphabetical order");
        System.out.println("106 or SPD : Store Program Data into file");
        System.out.println("107 or LPD : Load Program Data from file");
        System.out.println("108 or STK : View Remaining burgers Stock");
        System.out.println("109 or AFS : Add burgers to Stock");
        System.out.println("110 or AFS : View each queue income");
        System.out.println("999 or EXT : Exit the Program");


    }              // This method used to display menu
    public static void viewAllQueues(){

        System.out.println("*****************");
        System.out.println("     CASHIER     ");
        System.out.println("*****************");

        // Check the 1 queue has customers or not
        for(int i = 0;i < q1.length;i++){
            if (Objects.equals(q1[i][0], "0")){
                viewq1[i] = "X";  // If it is true it means it's occupied, view array that element replaces "X"
            }else
                viewq1[i] = "O";  // If it is false it means it's occupied, view array that element replaces "O"
        }
        for(int i = 0;i < q2.length;i++){
            if (Objects.equals(q2[i][0], "0")){
                viewq2[i] = "X";  // If it is true it means it's occupied, view array that element replaces "X"
            }else
                viewq2[i] = "O";  // If it is false it means it's occupied, view array that element replaces "O"
        }
        for(int i = 0;i < q3.length;i++){
            if (Objects.equals(q3[i][0], "0")){
                viewq3[i] = "X";  // If it is true it means it's occupied, view array that element replaces "X"
            }else
                viewq3[i] = "O";  // If it is false it means it's occupied, view array that element replaces "O"
        }

        // This will create interface to see each queue positions occupied or not
        System.out.println("\t"+viewq1[0]+"\t"+viewq2[0]+"\t"+viewq3[0]);
        System.out.println("\t"+viewq1[1]+"\t"+viewq2[1]+"\t"+viewq3[1]);
        System.out.println("\t"+"\t"+viewq2[2]+"\t"+viewq3[2]);
        System.out.println("\t"+"\t"+"\t"+viewq3[3]);
        System.out.println("\t"+"\t"+"\t"+viewq3[4]);
    }     // This method for display 3 queues parallel with whether occupied or not
    public static void viewEmptyQueues(){
        System.out.print("Empty positions in QUEUE 1 - ");
        for(int i = 0;i<q1.length;i++){
            if (Objects.equals(q1[i][0], "0")){     // Check queue 1 each element and check whether occupied or not,
                System.out.print(i+1 +" ");             // if it is not occupied position will be printed
            }
        }
        System.out.println();
        System.out.print("Empty positions in QUEUE 2 - ");
        for(int i = 0;i<q2.length;i++){
            if (Objects.equals(q2[i][0], "0")){     // Check queue 2 each element and check whether occupied or not,
                System.out.print(i+1 +" ");             // if it is not occupied position will be printed
            }
        }
        System.out.println();
        System.out.print("Empty positions in QUEUE 3 - ");
        for(int i = 0;i<q3.length;i++){
            if (Objects.equals(q3[i][0], "0")){    // Check queue 3 each element and check whether occupied or not,
                System.out.print(i+1 +" ");            // if it is not occupied position will be printed
            }
        }
        System.out.println();
    }   // This method for display empty positions with queue number
    public static void addCustomer(){
        try{
            addedToQueue = true;
            boolean foundEmptyPlace = false;

            Scanner customerInputs = new Scanner(System.in);

            System.out.print("Enter customer's first name  : ");
            String fname = customerInputs.nextLine();            // Get customer's first name and save as 'fname'
            System.out.print("Enter customer's last name   : ");
            String lname = customerInputs.nextLine();            // Get customer's last name and save as 'lname'
            System.out.print("Enter No.of burgers required : ");
            int noBurgersReq = customerInputs.nextInt();         // Get no of burgers customer required

            while (addedToQueue){

                // In this method, It checks the all first places in queue 1,2 and 3
                for(int i=0; i<3;i++){
                    if(Objects.equals(q123[i][0][0], "0")){
                        q123[i][0][0]= fname;
                        q123[i][0][1]= lname;
                        q123[i][0][2]= String.valueOf(noBurgersReq);
                        int qNum = i+1; // This variable used to display the queue number which is customer is added

                        if (i == 0)
                            bugersSoldQ1 = bugersSoldQ1 + noBurgersReq; // Increase the no of burgers sold in queue 1
                        else if (i == 1)
                            bugersSoldQ2 = bugersSoldQ2 + noBurgersReq; // Increase the no of burgers sold in queue 2
                        else
                            bugersSoldQ3 = bugersSoldQ3 + noBurgersReq; // Increase the no of burgers sold in queue 3

                        noOfBurgersStock = noOfBurgersStock - noBurgersReq; // Decrease the no of burgers customer ordered in stock

                        System.out.println(fname + " successfully added to the queue " + qNum ); // Display message which is removed customer name and queue
                        foundEmptyPlace = true;
                        break;
                    }
                }

                if (foundEmptyPlace) {
                    break; // If it finds empty place and store data, this will break the main loop unless below code execute and data will be duplicated
                }

                // In this method, It checks the all second places in queue 1,2 and 3
                for(int i=0; i<3;i++){
                    if(Objects.equals(q123[i][1][0], "0")){
                        q123[i][1][0]= fname;
                        q123[i][1][1]= lname;
                        q123[i][1][2]= String.valueOf(noBurgersReq);
                        int qNum = i+1; // This variable used to display the queue number which is customer is added

                        if (i == 0)
                            bugersSoldQ1 = bugersSoldQ1 + noBurgersReq; // Increase the no of burgers sold in queue 1
                        else if (i == 1)
                            bugersSoldQ2 = bugersSoldQ2 + noBurgersReq; // Increase the no of burgers sold in queue 2
                        else
                            bugersSoldQ3 = bugersSoldQ3 + noBurgersReq; // Increase the no of burgers sold in queue 3

                        noOfBurgersStock = noOfBurgersStock - noBurgersReq; // Decrease the no of burgers customer ordered in stock

                        System.out.println(fname + " successfully added to the queue " + qNum); // Display message which is removed customer name and queue
                        foundEmptyPlace = true; // This used to stop the main loop
                        break;
                    }
                }

                if (foundEmptyPlace) {
                    break; // If it finds empty place and stored data, this will break the main loop unless below code execute and data will be duplicated
                }

                // In this method, It checks the all third places in queue 2 and 3
                for(int i=1; i<3;i++){
                    if(Objects.equals(q123[i][2][0], "0")){
                        q123[i][2][0]= fname;
                        q123[i][2][1]= lname;
                        q123[i][2][2]= String.valueOf(noBurgersReq);

                        int qNum = i+1; // This variable used to display the queue number which is customer is added

                        if (i == 1)
                            bugersSoldQ2 = bugersSoldQ2 + noBurgersReq; // Increase the no of burgers sold in queue 2
                        else
                            bugersSoldQ3 = bugersSoldQ3 + noBurgersReq; // Increase the no of burgers sold in queue 3

                        noOfBurgersStock = noOfBurgersStock - noBurgersReq; // Decrease the no of burgers customer ordered in stock

                        System.out.println(fname + " successfully added to the queue " + qNum); // Display message which is removed customer name and queue
                        foundEmptyPlace = true;
                        break;
                    }
                }

                if (foundEmptyPlace) {
                    break; // If it finds empty place and store data, this will break the main loop unless below code execute and data will be duplicated
                }

                // In this method, It checks the all last two positions in queue 3
                for(int i=3; i<5;i++){
                    if(Objects.equals(q123[2][i][0], "0")){
                        q123[2][i][0]= fname;
                        q123[2][i][1]= lname;
                        q123[2][i][2]= String.valueOf(noBurgersReq);

                        bugersSoldQ3 = bugersSoldQ3 + noBurgersReq; // Increase the no of burgers sold in queue 3

                        noOfBurgersStock = noOfBurgersStock - noBurgersReq;

                        System.out.println(fname + " successfully added to the queue 3"); // Display message which is removed customer name and queue
                        foundEmptyPlace = true;
                        break;

                    } else if (!Objects.equals(q123[2][4][0], "0")) {
                        // If last positions of queue 3 is not empty, customer will be added to the waiting queue
                        waitingQueue[waitingNumber] = new String[]{fname, lname, String.valueOf(noBurgersReq)};
                        waitingNumber++;

                        System.out.println(fname + " added to the waiting queue due to the all queues are full");







                        addedToQueue = false;
                        break;
                    }
                }

                if (foundEmptyPlace) {
                    break; // If it finds empty place and store data, this will break the main loop unless below code execute and data will be duplicated
                }
            }

        }catch(Exception e) {
            System.out.println("""
                    Integer required! Please enter data again
                    """);
            addCustomer();
        }
    }       // This method for add customers to the queue
    public static void removeCustomer(){
        int removeQueue = 0;

        while (rightQueue){

            try{
                System.out.print("Enter queue number   : ");
                removeQueue = myObj.nextInt();

                // Check whether any customers are in queue 1
                if (removeQueue == 1){
                    for(String[] s: q1){
                        queueEmpty = true;
                        if(!Objects.equals(s[0], "0")){
                            queueEmpty = false;  // Inform that queue 1 is not empty
                            rightQueue = false;  // Stop the loop if there are any customers
                            break;
                        }
                    }
                    if (queueEmpty)  // If queue 1 has no any customers to remove, this will execute
                        System.out.println("This queue is empty");

                }
                // Check whether any customers are in queue 2
                else if (removeQueue == 2){
                    for(String[] s: q2){
                        queueEmpty = true;
                        if(!Objects.equals(s[0], "0")){
                            queueEmpty = false;  // Inform that queue 2 is not empty
                            rightQueue = false;  // Stop the loop if there are any customers
                            break;
                        }
                    }
                    if (queueEmpty)  // If queue 2 has no any customers to remove, this will execute
                        System.out.println("This queue is empty");



                }
                // Check whether any customers are in queue 3
                else if (removeQueue == 3){
                    for(String[] s: q3){
                        queueEmpty = true;
                        if(!Objects.equals(s[0], "0")){
                            queueEmpty = false;  // Inform that queue 3 is not empty
                            rightQueue = false;  // Stop the loop if there are any customers
                            break;
                        }
                    }
                    if (queueEmpty)  // If queue 3 has no any customers to remove, this will execute
                        System.out.println("This queue is empty");

                }
                // If user entered 999 Remove method will be stopped
                else if(removeQueue == 999){
                    rightQueue    = false;  // Stop the QUEUE CHECKING loop
                    rightPosition = false;  // Stop the POSITION CHECKING loop
                    break;
                }
            }
            catch (InputMismatchException e) {
                System.out.println("Please enter queue number as a INTEGER !!!");
                myObj.next(); // Consume the invalid input
            }


        }

        // If user enter correct queue number, this will ask which position customer need to remove
        while (rightPosition){

            try{
                System.out.print("Enter queue position : ");
                int queuePosition = myObj.nextInt();

                // Check weather entered position in queue 1 has a customer, if true remove the customer from queue 1
                if(removeQueue == 1 && queuePosition<3 && queuePosition>0 && !Objects.equals(q1[queuePosition - 1][0], "0")){

                    // When user remove specific customer, rest of them will come to forward
                    if(queuePosition == 1){
                        bugersSoldQ1 = bugersSoldQ1 - Integer.parseInt(q1[queuePosition-1][2]);
                        System.out.println(q1[queuePosition-1][0]+ " removed from the " + (removeQueue) + " queue");
                        q1[0] = q1[1];
                        q2[1] = waitingQueue[0];
                        rearrangeWaitingQueue();
                        break;
                    } else {
                        System.out.println(q1[queuePosition-1][0]+ " removed from the " + (removeQueue) + " queue");
                        q2[2] = waitingQueue[0];
                        rearrangeWaitingQueue();
                        break;
                    }
                }
                // Check weather entered position in queue 2 has a customer, if true remove the customer from queue 2
                else if(removeQueue == 2 && queuePosition<4 && queuePosition>0 &&!Objects.equals(q2[queuePosition - 1][0], "0")){

                    // When user remove specific customer, rest of them will come to forward
                    if(queuePosition == 1){
                        bugersSoldQ2 = bugersSoldQ2 - Integer.parseInt(q2[queuePosition-1][2]);
                        System.out.println(q2[queuePosition-1][0]+ " removed from the " + (removeQueue) + " queue");
                        q2[0] = q2[1];
                        q2[1] = q2[2];
                        q2[2] = waitingQueue[0];
                        rearrangeWaitingQueue();
                        break;
                    } else if (queuePosition == 2){
                        bugersSoldQ2 = bugersSoldQ2 - Integer.parseInt(q2[queuePosition-1][2]);
                        System.out.println(q2[queuePosition-1][0]+ " removed from the " + (removeQueue) + " queue");
                        q2[1] = q2[2];
                        q2[2] = waitingQueue[0];
                        rearrangeWaitingQueue();
                        break;
                    } else {
                        bugersSoldQ2 = bugersSoldQ2 - Integer.parseInt(q2[queuePosition-1][2]);
                        System.out.println(q2[queuePosition-1][0]+ " removed from the " + (removeQueue) + " queue");
                        q2[2] = waitingQueue[0];
                        rearrangeWaitingQueue();
                        break;
                    }

                }
                // Check weather entered position in queue 3 has a customer, if true remove the customer from queue 3
                else if(removeQueue == 3 && queuePosition<6 && !Objects.equals(q3[queuePosition - 1][0], "0")){

                    // When user remove specific customer, rest of them will come to forward
                    if(queuePosition == 1){
                        bugersSoldQ3 = bugersSoldQ3 - Integer.parseInt(q3[queuePosition-1][2]);
                        System.out.println(q3[queuePosition-1][0]+ " removed from the " + (removeQueue) + " queue");
                        q3[0] = q3[1];
                        q3[1] = q3[2];
                        q3[2] = q3[3];
                        q3[3] = q3[4];
                        q3[4] = waitingQueue[0];

                        rearrangeWaitingQueue();
                        break;
                    } else if (queuePosition == 2){
                        bugersSoldQ3 = bugersSoldQ3 - Integer.parseInt(q3[queuePosition-1][2]);
                        System.out.println(q3[queuePosition-1][0]+ " removed from the " + (removeQueue) + " queue");
                        q3[1] = q3[2];
                        q3[2] = q3[3];
                        q3[3] = q3[4];
                        q3[4] = waitingQueue[0];
                        rearrangeWaitingQueue();
                        break;
                    } else if (queuePosition == 3){
                        bugersSoldQ3 = bugersSoldQ3 - Integer.parseInt(q3[queuePosition-1][2]);
                        System.out.println(q3[queuePosition-1][0]+ " removed from the " + (removeQueue) + " queue");
                        q3[2] = q3[3];
                        q3[3] = q3[4];
                        q3[4] = waitingQueue[0];
                        rearrangeWaitingQueue();
                        break;
                    }else if (queuePosition == 4){
                        bugersSoldQ3 = bugersSoldQ3 - Integer.parseInt(q3[queuePosition-1][2]);
                        System.out.println(q3[queuePosition-1][0]+ " removed from the " + (removeQueue) + " queue");
                        q3[3] = q3[4];
                        q3[4] = waitingQueue[0];
                        rearrangeWaitingQueue();
                        break;
                    } else {
                        bugersSoldQ3 = bugersSoldQ3 - Integer.parseInt(q3[queuePosition-1][2]);
                        System.out.println(q3[queuePosition-1][0]+ " removed from the " + (removeQueue) + " queue");
                        q3[4] = waitingQueue[0];
                        rearrangeWaitingQueue();
                        break;
                    }
                }
            }
            catch (InputMismatchException e) {
                System.out.println("Please enter queue position as a INTEGER !!!");
                myObj.next();
            }

        }

        rightQueue = true;
        noCustomers = false;

    }    // If user want to remove a customer, this method will be called
    public static void writeFile() throws FileNotFoundException {

        PrintWriter outputFile = new PrintWriter("SD2.txt");

        outputFile.println("""
                            
                            This is queue 1 customer details ______________________________________
                            """);

        for (int i = 0; i<q1.length;i++){
            int k = i+1;
            if(Objects.equals(q1[i][0], "0")){
                outputFile.println("0");
                outputFile.println("0");
                outputFile.println("0");
            }else{
                outputFile.println(q1[i][0]);
                outputFile.println(q1[i][1]);
                outputFile.println(q1[i][2]);

            }
            outputFile.println();
        }

        outputFile.println("""
                            
                            This is queue 2 customer details ______________________________________
                            """);

        for (int i = 0; i<q2.length;i++){
            int k = i+1;
            if(Objects.equals(q2[i][0], "0")){
                outputFile.println("0");
                outputFile.println("0");
                outputFile.println("0");
            }else{
                outputFile.println(q2[i][0]);
                outputFile.println(q2[i][1]);
                outputFile.println(q2[i][2]);
            }
            outputFile.println();
        }

        outputFile.println("""
                            
                            This is queue 3 customer details ______________________________________
                            """);

        for (int i = 0; i<q3.length;i++){
            int k = i+1;
            if(Objects.equals(q3[i][0], "0")){
                outputFile.println("0");
                outputFile.println("0");
                outputFile.println("0");

            }else{
                outputFile.println(q3[i][0]);
                outputFile.println(q3[i][1]);
                outputFile.println(q3[i][2]);
            }
            outputFile.println();
        }

        outputFile.close();


        System.out.println("Queue data has been sucessfully saved in 'SD2.txt' file");
    }  // This method will be stored data from the text file
    public static void loadFile() throws FileNotFoundException {

        Scanner infile = new Scanner(new File("SD2.txt"));

        for(int emptyLineSet = 0; emptyLineSet<3;emptyLineSet++){
            String line1 = infile.nextLine();  // In my text file there are empty line, this code will be skipped that
        }

        for(int l1=0;l1<2;l1++){
            for(int i = 0; i<3;i++){
                q1[l1][i] = infile.nextLine();
            }
            String line7 = infile.nextLine();
        }

        for(int emptyLineSet = 0; emptyLineSet<3;emptyLineSet++){
            String line1 = infile.nextLine();  // In my text file there are empty line, this code will be skipped that
        }

        for(int l2=0; l2<3;l2++){
            for(int i = 0; i<3;i++){
                q2[l2][i] = infile.nextLine();
            }
            String line18 = infile.nextLine();
        }

        for(int emptyLineSet = 0; emptyLineSet<3;emptyLineSet++){
            String line1 = infile.nextLine();  // In my text file there are empty line, this code will be skipped that
        }

        for(int l3 = 0; l3<5; l3++){
            for(int i = 0; i<3;i++){
                q3[l3][i] = infile.nextLine();
            }

            String line33 = infile.nextLine();
        }

        System.out.println("Data successfully load in to Queue 1/ Queue 2/ Queue 3");

    }   // This method will be loaded data from the text file
    public static void removeServedCustomer(){
        while (rightServedQueue){
            try{
                System.out.print("Enter queue served number : ");
                int servedQueue = myObj.nextInt();

                if (servedQueue == 1 && !Objects.equals(q1[0][0], "0")){
                    System.out.println(q1[0][0] + " has been served");
                    q1[0] = q1[1];
                    q1[1] = waitingQueue[0];
//                    q1[1] = new String[]{"0","0","0"};

                    rearrangeWaitingQueue();
                    break;
                }

                else if (servedQueue == 2 && !Objects.equals(q2[0][0], "0")) {
                    System.out.println(q2[0][0] + " removed from 2 queue.");
                    q2[0]=q2[1];
                    q2[1]=q2[2];
                    q2[2]=waitingQueue[0];
//                    q2[2] = new String[]{"0","0","0"};

                    rearrangeWaitingQueue();
                    break;
                }
                else if (servedQueue == 3 && !Objects.equals(q3[0][0], "0")) {
                    System.out.println(q3[0][0] + " removed from 3 queue.");
                    q3[0]=q3[1];
                    q3[1]=q3[2];
                    q3[2]=q3[3];
                    q3[3]=q3[4];
                    q3[4]=waitingQueue[0];
//                    q3[4] = new String[]{"0","0","0"};

                    rearrangeWaitingQueue();
                    break;
                }
                else{
                    System.out.println("This Queue has no customers to serve !!");
                    break;
                }


            }
            catch(InputMismatchException e) {
                System.out.println("Please enter queue number as a INTEGER !!!");
                myObj.next();
            }



        }
    }  // After serving customer in specific queue, customer will be removed
    public static void refillStock(){
        while (true){
            System.out.print("How many bugers do you need to add : ");
            int addBurgers = myObj.nextInt();

            noOfBurgersStock = noOfBurgersStock + addBurgers;

            if(noOfBurgersStock > 50){
                noOfBurgersStock = noOfBurgersStock - addBurgers;
                System.out.println("Please burgers amount can not be exceeded!");
            }else{
                System.out.println("Currently there are "+ noOfBurgersStock + " burgers in stock");
                break;
            }
        }
    }           // This method used for,If user want to refill the stock
    public static void sortedNames(){

        int custermersQueues =0;

        for (String[] strings : q1) {                   // Count how many customers in queue 1
            if (!Objects.equals(strings[0], "0")) {
                custermersQueues++;
            }
        }
        for (String[] strings : q2) {                   // Count how many customers in queue 2
            if (!Objects.equals(strings[0], "0")) {
                custermersQueues++;
            }
        }
        for (String[] strings : q3) {                   // Count how many customers in queue 3
            if (!Objects.equals(strings[0], "0")) {
                custermersQueues++;
            }
        }

        String[] names = new String[custermersQueues];  // Create a new array with length, no.of customers in all queues

        int namesArrIndex=0;
        for (String[] strings : q1) {
            if (!Objects.equals(strings[0], "0")) {  //  If customers are in queue 1, add to names array
                names[namesArrIndex] = strings[0] + " " + strings[1];
                namesArrIndex++;
            }
        }
        for (String[] strings : q2) {
            if (!Objects.equals(strings[0], "0")) {  //  If customers are in queue 2, add to names array
                names[namesArrIndex] = strings[0] + " " + strings[1];
                namesArrIndex++;
            }
        }
        for (String[] strings : q3) {
            if (!Objects.equals(strings[0], "0")) {  //  If customers are in queue 3, add to names array
                names[namesArrIndex] = strings[0] + " " + strings[1];
                namesArrIndex++;
            }
        }

        int length = names.length;
        for (int i = 0; i < length; i++) {
            for (int j = 0; j < length - i - 1; j++) {
                if (names[j].charAt(0) > names[j + 1].charAt(0) || (names[j].charAt(0) == names[j + 1].charAt(0) && names[j].charAt(1) > names[j + 1].charAt(1))) {
                    String temp = names[j];
                    names[j] = names[j + 1];
                    names[j + 1] = temp;
                }
            }
        }

        for (String element:names){
            System.out.println(element);  // Print the sorted names
        }
    }           // To sort all customers name in the queues this will be called
    public static void exit(){
        System.out.println("👋 Thank you");
        op = false;
        againMenu = false;
    }                  // When user want to exit the program, this method will be called
    public static void rearrangeWaitingQueue(){
        for(int i=0; i< waitingQueue.length-1 ;i++){
            waitingQueue[i] = waitingQueue[i+1];
        }
        waitingQueue[waitingQueue.length-1] = new String[]{"0","0","0"};
        waitingNumber--;
    }
}

